//
//  Task.h
//  AssignmentWork
//
//  Created by Tanim-UTC on 9/4/17.
//  Copyright © 2017 SODING. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Task : NSObject

@property(nonatomic, strong)NSString *name;
@property(nonatomic, strong)NSString *discription;
@property(nonatomic, strong)NSString *createdDate;
@property(nonatomic, strong)NSString *updatedDate;

@end
