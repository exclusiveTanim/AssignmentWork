//
//  TaskDetailsViewController.h
//  AssignmentWork
//
//  Created by Tanim-UTC on 9/4/17.
//  Copyright © 2017 SODING. All rights reserved.
//

#import "ViewController.h"

@interface TaskDetailsViewController : ViewController

@end
