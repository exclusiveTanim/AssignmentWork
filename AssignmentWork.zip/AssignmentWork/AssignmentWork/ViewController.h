//
//  ViewController.h
//  AssignmentWork
//
//  Created by Tanim-UTC on 9/2/17.
//  Copyright © 2017 SODING. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Task.h"
#import "sqlite3.h"

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *disField;
@property (weak, nonatomic) IBOutlet UITextField *createdDateField;
@property (weak, nonatomic) IBOutlet UITextField *updatedDateField;
@property (weak, nonatomic) IBOutlet UITableView *myTableView;

- (IBAction)saveData:(id)sender;
- (IBAction)displayData:(id)sender;
- (IBAction)deleteData:(id)sender;
- (IBAction)editData:(id)sender;


@end

