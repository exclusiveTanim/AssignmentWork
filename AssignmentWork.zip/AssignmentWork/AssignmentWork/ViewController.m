//
//  ViewController.m
//  AssignmentWork
//
//  Created by Tanim-UTC on 9/2/17.
//  Copyright © 2017 SODING. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *arrayOfTask;
    sqlite3 *taskDB;
    NSString *dbPathString;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrayOfTask = [[NSMutableArray alloc]init];
    [[self myTableView]setDelegate:self];
    [[self myTableView]setDataSource:self];
    [self createOrOpenDB];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)createOrOpenDB
{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    
    dbPathString = [docPath stringByAppendingPathComponent:@"tasts.db"];
    
    char *error;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:dbPathString]) {
        const char *dbPath = [dbPathString UTF8String];
        
        //creat db here
        if (sqlite3_open(dbPath, &taskDB)==SQLITE_OK) {
            const char *sql_stmt = "CREATE TABLE IF NOT EXISTS TASKS (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DISCRIPTION TEXT, CREATEDDATE TEXT, UPDATEDDATE TEXT )";
            sqlite3_exec(taskDB, sql_stmt, NULL, NULL, &error);
            sqlite3_close(taskDB);
        }
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayOfTask count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    Task *aTask = [arrayOfTask objectAtIndex:indexPath.row];
    
    cell.textLabel.text = aTask.name;
    cell.detailTextLabel.text = aTask.discription;
    //[NSString stringWithFormat:@"%d",aTask.age];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)saveData:(id)sender{
    char *error;
    if (sqlite3_open([dbPathString UTF8String], &taskDB)==SQLITE_OK) {
        NSString *inserStmt = [NSString stringWithFormat:@"INSERT INTO TASKS(NAME,DISCRIPTION,CREATEDDATE,UPDATEDDATE) values ('%s','%s','%s','%s')",[self.nameField.text UTF8String],[self.disField.text UTF8String],[self.createdDateField.text UTF8String],[self.updatedDateField.text UTF8String]];
        
        const char *insert_stmt = [inserStmt UTF8String];
        
        if (sqlite3_exec(taskDB, insert_stmt, NULL, NULL, &error)==SQLITE_OK) {
            NSLog(@"Task added");
            
            Task *task = [[Task alloc]init];
            
            [task setName:self.nameField.text];
            [task setDiscription:self.disField.text];
            [task setCreatedDate:self.createdDateField.text];
            [task setUpdatedDate:self.updatedDateField.text];
            //[task setAge:[self.ageField.text intValue]];
            
            [arrayOfTask addObject:task];
        }
        sqlite3_close(taskDB);
    }


}
- (IBAction)displayData:(id)sender{
    sqlite3_stmt *statement;
    
    if (sqlite3_open([dbPathString UTF8String], &taskDB)==SQLITE_OK) {
        [arrayOfTask removeAllObjects];
        
        NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM TASKS"];
        const char* query_sql = [querySql UTF8String];
        
        if (sqlite3_prepare(taskDB, query_sql, -1, &statement, NULL)==SQLITE_OK) {
            while (sqlite3_step(statement)==SQLITE_ROW) {
                NSString *name = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
                NSString *dis = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
                
                Task *task = [[Task alloc]init];
                
                [task setName:name];
                [task setDiscription:dis];
                //[person setAge:[ageString intValue]];
                
                [arrayOfTask addObject:task];
            }
        }
    }
    [[self myTableView]reloadData];

}

- (IBAction)deleteData:(id)sender{
    [[self myTableView]setEditing:!self.myTableView.editing animated:YES];
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        Task *p = [arrayOfTask objectAtIndex:indexPath.row];
        [self deleteDataq:[NSString stringWithFormat:@"Delete from tasks where name is '%s'", [p.name UTF8String]]];
        [arrayOfTask removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

-(void)deleteDataq:(NSString *)deleteQuery
{
    char *error;
    
    if (sqlite3_exec(taskDB, [deleteQuery UTF8String], NULL, NULL, &error)==SQLITE_OK) {
        NSLog(@"Task deleted");
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [[self disField]resignFirstResponder];
    [[self nameField]resignFirstResponder];
}

- (IBAction)editData:(id)sender{
  [[self myTableView]setEditing:!self.myTableView.editing animated:YES];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"ShowDetails"]) {
    }
}

@end
